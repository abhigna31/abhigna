import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comparesector',
  templateUrl: './comparesector.component.html',
  styleUrls: ['./comparesector.component.css']
})
export class ComparesectorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
