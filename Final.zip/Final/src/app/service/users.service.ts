import { Injectable, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../models/users';
@Injectable({
  providedIn: 'root'
})
export class UsersService {
  httpUrl = 'http://localhost:8000/user/';
  user: User[];

  constructor(private httpClient: HttpClient, @Inject(HttpClient) private ht) { }
  getAllUsers(): Observable<User[]> {
    return this.httpClient.get<User[]>(this.httpUrl);
  }
  saveUsers(com: User): Observable<User> {
    return this.ht.post(this.httpUrl+"addUser/", com);
  }
  reg(){
    return this.ht.get(`http://localhost:8000/user/`)
  }

  deleteUsers(id: number): Observable<User> {
    return this.ht.delete(`http://localhost:8000/user/${id}`);
  }
  updateUsers(com: User): Observable<User> {
    return this.ht.put(` http://localhost:8000/user/`, com);
  }
  getUsersById(id: number): Observable<User> {
    return this.ht.get(`http://localhost:8000/user/${id}`);
    }

    serActivation(obj){
      return this.ht.put(`http://localhost:8000/user/activate`,obj)
    }
}  

