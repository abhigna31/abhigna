import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CompanyService } from 'src/app/company.service';
import { Company } from 'src/app/models/Company';

@Component({
  selector: 'app-comparecompany',
  templateUrl: './comparecompany.component.html',
  styleUrls: ['./comparecompany.component.css']
})
export class ComparecompanyComponent implements OnInit {
  compareCompany: FormGroup;
  companies: Company[];
  constructor(private formBulder: FormBuilder, private companyService: CompanyService,private router:Router) { }
  ngOnInit() {
    this.compareCompany = this.formBulder.group({
      csselect: ['',Validators.required],
      seselect: ['',Validators.required],
      cnsn: ['',Validators.required],
      ctcnsn: ['',Validators.required],
      fperiod: ['',Validators.required],
      tperiod: ['',Validators.required],
      
    });
    this.companyService.getAllCompany().subscribe(data => {
      console.log(data);
      this.companies = data;
    }); 
  }
  onSubmit() {
    this.router.navigate(["/charts"],{
      queryParams:{
        formData: JSON.stringify(this.compareCompany.value)
      }
    });

 
 
}
}