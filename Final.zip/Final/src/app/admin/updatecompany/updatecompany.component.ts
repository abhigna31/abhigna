import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Company } from 'src/app/models/Company';
import { CompanyService } from 'src/app/company.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-updatecompany',
  templateUrl: './updatecompany.component.html',
  styleUrls: ['./updatecompany.component.css']
})
export class UpdatecompanyComponent implements OnInit {

  updateTheCompany :FormGroup;
  constructor(private formBuilder:FormBuilder,private companyService:CompanyService,private router:Router) { }

  ngOnInit() {
    this.updateTheCompany=this.formBuilder.group({
    id:['',Validators.required],
    sector:['',Validators.required],
    name:['',Validators.required],
    ceo:['',Validators.required],
    bod:['',Validators.required],
    turnover:['',Validators.required],
  });
  const id=localStorage.getItem('companyId');
  if(+id > 0){
    console.log("update::id "+id);
    this.companyService.getCompanyById(+id).subscribe(comp => {
      this.updateTheCompany.patchValue(comp);
    });
  }
}
updateCompany(){
  this.companyService.update(this.updateTheCompany.value).subscribe(u =>{
    this.router.navigate(['/companylist'])
  });
}
}