import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deletecompany',
  templateUrl: './deletecompany.component.html',
  styleUrls: ['./deletecompany.component.css']
})
export class DeletecompanyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
