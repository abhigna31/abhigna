
export class User
{
     id: number;
     email: String;
     firstname: String;
     lastname: string;
     username: string;
     password: string;
     phone: string;
     active:Boolean;
     regstatus:string;
     role: string;
    
}