export class Company{

    id:number;
    sector:string;
    name:string;
    ceo:string;
    bod:string;
   // stocklist:string;
    turnover:number;
    companyCode:string;
    
}