// import { User} from './users';

// export const USERS: User[]= [
//    {id:101, username:'tanu', password: '123'},
//    {id:102, username:'sree', password: '456'},
// ];
