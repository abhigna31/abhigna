export class StockExchange{

    id:number;
    name:string;
    remarks:string;
    
}