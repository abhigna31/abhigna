export class Ipolist{

    id:number;
    companyname:string;
    stockexchange:string;
    ppshare:number;
    shares:number;
    datetime:String;
    remarks:String;
    
}