import { Injectable, Inject } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Company } from './models/Company';
import { Observable } from 'rxjs';
import { User } from './models/users';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CompanyService {
  
  
  httpUrl = environment.host +"company-service/company/";
 
com:Company;

constructor(private httpClient:HttpClient, @Inject(HttpClient)  private ht) { }

getAllCompany()
{
  return this.httpClient.get<Company[]>(this.httpUrl);
}
saveCompany(com:Company):Observable<Company>
{
  return this.ht.post(this.httpUrl,com);
}

  deleteCompany(id:number):Observable<Company>{
    return this.ht.delete(this.httpUrl,+id);
 }
update(com:Company):Observable<Company>{
  // console.log("compa uodate: "+com.ceo+"  "+com.name);
  return this.ht.put(this.httpUrl,com);
}
 getCompanyById(id:number):Observable<Company>{
  return this.ht.get(this.httpUrl,id);
 }
getUserByCompany(user:User[]):Observable<User[]>{
  return this.httpClient.get<User[]>(this.httpUrl);
}
}

