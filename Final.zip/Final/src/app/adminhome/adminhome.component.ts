import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminhome',
  templateUrl: './adminhome.component.html',
  styleUrls: ['./adminhome.component.css']
})
export class AdminhomeComponent implements OnInit {

  constructor(private router:Router) { }

  importdata(){
    this.router.navigate(['/importdata']);
  }
  companydet(){
    this.router.navigate(['/companydetails']);
  }
  stockEx(){
    this.router.navigate(['/stockExchange']);
  }
  ipodet(){
    this.router.navigate(['/ipodetails']);
  }
  addipo(){
    this.router.navigate(['/addipo']);
  }
  ipolist(){
    this.router.navigate(['/ipolist']);
  }
  addcompany(){
    this.router.navigate(['/addcompany']);
  }
  company(){
    this.router.navigate(['/company']);
  }
  stadd(){
    this.router.navigate(['/addstockexchange']);
  }
  stlist(){
    this.router.navigate(['/stockexchangelist']);
  }
  users(){
    this.router.navigate(['/users']);
  }
  logout(){
    this.router.navigate(['/logout']);
  }

  ngOnInit() {
  }

}
