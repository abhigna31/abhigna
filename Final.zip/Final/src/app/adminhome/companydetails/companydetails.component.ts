import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-companydetails',
  templateUrl: './companydetails.component.html',
  styleUrls: ['./companydetails.component.css']
})
export class CompanydetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
