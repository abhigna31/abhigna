import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { UsersService } from '../service/users.service';
import { User } from '../models/users';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  registrationForm: FormGroup
  users: User[] = [];

  constructor(private formBuilder:FormBuilder, private service: ServiceService) { }

  ngOnInit() {
    this.registrationForm=this.formBuilder.group({
      id:[],
      email:['',[Validators.email,Validators.required]],
      firstname:['',[Validators.required]],
      lastname:['',[Validators.required]],
      password:['',[Validators.required]],
      phone:['',[Validators.required]],
      username:['',[Validators.required]]
    });
    this.service.getAllUsers().subscribe(u => {this.users = u;})
  }
  emailValid(mail : String){
    for(let user of this.users){
      if(user.email===mail){
        return false;
      }
    }
    return true;
  }
  addUser(){
    let e = this.registrationForm.controls.email.value;
    if(this.emailValid(e)){
      this.service.saveUser(this.registrationForm.value).subscribe(data => {
         alert('User Inserted Successfully' +data);
         alert('coming status'+data.regstatus);
         alert('Registered Successfully')
         this.registrationForm.reset()
        }); }
        else
        {
          alert('already Email exsits')
          this.registrationForm.reset()
        }
  }
//  deleteUser(){
//   this.userService.deleteUsers(this.registerForm.value).subscribe(data=>{
//     alert('User Deleted Successfully' +data);
//   });
// // }
  onSubmit(){
  //  this.service.reg().subscribe(dt=>{
    //  console.log("coming status::::"+dt.reg);
  //  })
      console.log("inserted");
  }


}
