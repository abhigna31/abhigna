import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ipodetails',
  templateUrl: './ipodetails.component.html',
  styleUrls: ['./ipodetails.component.css']
})
export class IpodetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
