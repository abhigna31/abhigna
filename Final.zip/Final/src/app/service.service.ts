import { Injectable, Inject } from '@angular/core';
//import { USERS } from '../app/models/mock-user'; 
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../app/models/users'
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  
  
  httpUrl = environment.host +"user-service/user/";
   users =User;
  
  constructor(private httpClient: HttpClient, @Inject(HttpClient) private ht) { }
 
  getAllUsers():Observable<User[]>{
    return this.ht.get("http://localhost:8765/user-service/user/");
  }

  saveUser(user : User): Observable<User>{
    return this.ht.post("http://localhost:8765/user-service/user/addUser", user);
  }
  deleteUser(id:number):Observable<User>{
    return this.ht.delete(environment.host +"user-service/user/"+id);
 }
updateUser(user:User):Observable<User>{
  return this.ht.put(environment.host +"user-service/user/",user);
}
 getUserById(id:number):Observable<User>{
  return this.ht.get(environment.host +"user-service/user/"+id);
 }

 serviceActivation(obj){
   return this.ht.put(environment.host +"user-service/activate",obj)
 }
 LoggedIn(){
  let user_id=localStorage.getItem('userId');
  if(user_id==null)
  return false;
  else return true;
}
isActivated(user:User){
  if(user.active==true){
        return false;

  }
}
  isAdmin()
 {
   if(sessionStorage.getItem("usertype")=="admin")
   {
     return true;
   }
   else {
     return false;
   }
 }
}

