import { Injectable, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Ipolist } from './models/ipolist';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class IpolistService {

  httpUrl = environment.host +"initial-public-offering-service/ipo/";
ipo:Ipolist;

constructor(private httpClient:HttpClient, @Inject(HttpClient)  private ht) { }

getAllIpo(): Observable<Ipolist[]>
{
  return this.httpClient.get<Ipolist[]>(this.httpUrl);
}
saveIpo(ipo:Ipolist):Observable<Ipolist>
{
  return this.ht.post(this.httpUrl,ipo);
}

  deleteIpo(id:number):Observable<Ipolist>{
    return this.ht.delete(this.httpUrl+id);
 }
updateIpoInfo(ipo:Ipolist):Observable<Ipolist>{
  //console.log("ipos update: "+ipo.ppshare+"  "+ipo.companyname);
  return this.ht.put(this.httpUrl,ipo);
}
 getIpoById(id:number):Observable<Ipolist>{
  return this.ht.get(this.httpUrl+id);
 }

}

