package com.cts.training.initialpublicofferingservice;

import java.util.List;


public interface InitialPublicOfferingService {
	
public List<InitialPublicOffering> getAllCompanies();
	
	public InitialPublicOffering insert(InitialPublicOffering ipo);
	public InitialPublicOffering update(InitialPublicOffering ipo);
	public InitialPublicOffering getIpoById(int id);
	public void delete(int id);
	}
	

