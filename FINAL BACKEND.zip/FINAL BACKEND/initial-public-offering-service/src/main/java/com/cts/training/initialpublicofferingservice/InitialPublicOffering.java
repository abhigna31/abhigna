package com.cts.training.initialpublicofferingservice;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ipo")

public class InitialPublicOffering {
	
	@Id
	@GeneratedValue
	private int id;
	private String companyname;
	private String stockexchange;
	private int ppshare;
	private int shares;
	private String datetime;
	private String remarks;
	
	public InitialPublicOffering() {
	}
	public int getId() 
	{
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCompanyname() {
		return companyname;
	}
	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}
	public String getStockexchange() {
		return stockexchange;
	}
	public void setStockexchange(String stockexchange) {
		this.stockexchange = stockexchange;
	}
	public int getPpshare() {
		return ppshare;
	}
	public void setPpshare(int ppshare) {
		this.ppshare = ppshare;
	}
	public int getShares() {
		return shares;
	}
	public void setShares(int shares) {
		this.shares = shares;
	}
	public String getDatetime() {
		return datetime;
	}
	public void setDatetime(String datetime) {
		this.datetime = datetime;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	@Override
	public String toString() {
		return "InitialPublicOffering [id=" + id + ", companyname=" + companyname + ", stockexchange=" + stockexchange
				+ ", ppshare=" + ppshare + ", shares=" + shares + ", datetime=" + datetime + ", remarks=" + remarks
				+ "]";
	}
	
	

}
