package com.cts.training.initialpublicofferingservice;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "*")
@RestController
public class IntialPublicOfferingController {
	@Autowired
	InitialPublicOfferingRepo initialpublicofferingrepo;
	
	@Autowired
	InitialPublicOfferingService initialpublicofferingService;
	
	@GetMapping("/ipo")
	public List<InitialPublicOffering> getAllInitialPublicOffering()
	{
		return initialpublicofferingrepo.findAll();
	}
	
	
	@GetMapping("/ipo/{id}")
	public InitialPublicOffering getInitialPublicOfferingById(@PathVariable int id)
	{
		Optional<InitialPublicOffering> initialpublicofferingList=initialpublicofferingrepo.findById(id);
		InitialPublicOffering initialpublicoffering=initialpublicofferingList.get();
		return initialpublicoffering;
	}

	@PostMapping("/ipo")
	public ResponseEntity<InitialPublicOffering> save(@RequestBody InitialPublicOffering ipo)
	{
		initialpublicofferingService.insert(ipo);
		return new ResponseEntity<InitialPublicOffering>(ipo,HttpStatus.CREATED); 
	}
	
	@PutMapping("/ipo")
	public ResponseEntity<InitialPublicOffering> update(@RequestBody InitialPublicOffering initialpublicoffering)
	{
		initialpublicofferingService.update(initialpublicoffering);
		return  new ResponseEntity<InitialPublicOffering>(HttpStatus.OK);
	}
	
	@DeleteMapping("/ipo/{id}")
	public ResponseEntity<InitialPublicOffering> delete(@PathVariable int id)
	{
		initialpublicofferingService.delete(id);
		return new ResponseEntity<InitialPublicOffering>(HttpStatus.OK);
	}
}


