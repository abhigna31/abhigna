package com.cts.training.initialpublicofferingservice;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class InitialPublicOfferingServiceImpl implements InitialPublicOfferingService{

	@Autowired
	InitialPublicOfferingRepo initialpublicofferingrepo;
	
	
	
	@Override
	public InitialPublicOffering insert(InitialPublicOffering ipo) {
		InitialPublicOffering initialpublicoffering=new InitialPublicOffering();
		BeanUtils.copyProperties(ipo, initialpublicoffering);
		initialpublicofferingrepo.save(initialpublicoffering);
		return ipo;
	}

	@Override
	public InitialPublicOffering update(InitialPublicOffering ipo) {
		InitialPublicOffering initialpublicoffering=new InitialPublicOffering();
		BeanUtils.copyProperties(ipo, initialpublicoffering);
		BeanUtils.copyProperties(initialpublicofferingrepo.save(initialpublicoffering), ipo);
		return ipo;
	}

	@Override
	public void delete(int id) {
		initialpublicofferingrepo.deleteById(id);
		
	}

	@Override
	public List<InitialPublicOffering> getAllCompanies() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public InitialPublicOffering getIpoById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}

