package com.cts.training.initialpublicofferingservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InitialPublicOfferingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
