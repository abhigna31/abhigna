package com.cts.training.stockexchangeservice;

import java.util.List;


public interface StockExchangeService {
	
public List<StockExchange> getAllStockExchanges();
	
	public StockExchange insert(StockExchange se);
	public StockExchange update(StockExchange se);
	public void delete(int id);

}
