package com.cts.training.stockexchangeservice;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "*")
@RestController



public class StockExchangeController{
	@Autowired
	StockExchangeRepo stockexchangerepo;
	
	@Autowired
	StockExchangeService stockexchangeService;
	
	@GetMapping("/stockexchange")
	public List<StockExchange> getAllStockExchange()
	{
		return stockexchangeService.getAllStockExchanges();
	}
	
	
	@GetMapping("/stockexchange/{id}")
	public StockExchange getStockExchangeById(@PathVariable int id)
	{
		Optional<StockExchange> stockexchangeList=stockexchangerepo.findById(id);
		StockExchange stockexchange=stockexchangeList.get();
		return stockexchange;
	}

	@PostMapping("/stockexchange")
	public ResponseEntity<StockExchange> save(@RequestBody StockExchange stockexchange)
	{
		stockexchangeService.insert(stockexchange);
		return new ResponseEntity<StockExchange>(stockexchange,HttpStatus.OK); 
	}
	
	@PutMapping("/stockexchange/{id}")
	public ResponseEntity<StockExchange> update(@RequestBody StockExchange stockexchange)
	{
		stockexchangeService.update(stockexchange);
		return  new ResponseEntity<StockExchange>(HttpStatus.OK);
	}
	
	@DeleteMapping("/stockexchange/{id}")
	public ResponseEntity<StockExchange> delete(@PathVariable int id)
	{
		stockexchangeService.delete(id);
		return new ResponseEntity<StockExchange>(HttpStatus.OK);
	}
}


