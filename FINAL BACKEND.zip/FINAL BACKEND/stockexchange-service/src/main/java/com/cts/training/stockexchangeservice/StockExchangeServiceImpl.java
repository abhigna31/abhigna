package com.cts.training.stockexchangeservice;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

	@Service
	public class StockExchangeServiceImpl implements StockExchangeService{

		@Autowired
		StockExchangeRepo stockexchangerepo;
		
		
		
		@Override
		public StockExchange insert(StockExchange stockexchange) {
			StockExchange stock=new StockExchange();
			BeanUtils.copyProperties(stockexchange, stock);
			stockexchangerepo.save(stock);
			return stockexchange;
		}

		@Override
		public StockExchange update(StockExchange stockexchange) {
			StockExchange stock=new StockExchange();
			BeanUtils.copyProperties(stockexchange, stock);
			BeanUtils.copyProperties(stockexchangerepo.save(stock), stockexchange);
			return stockexchange;
		}

		@Override
		public void delete(int id) {
			stockexchangerepo.deleteById(id);
		}

		@Override
		public List<StockExchange> getAllStockExchanges() {
				return stockexchangerepo.findAll();
		}

}

