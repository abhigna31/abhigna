package com.cts.training.companyservice;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

//@FeignClient(name="user-service")
@FeignClient("netflix-zuul-api-gateway-server")
public interface UserServiceProxy {
	//@FeignClient(name="user-service",url="http://localhost:8000")//accept only from one port as url is having only one port number
	
		@GetMapping("/user-service/user")
		public ResponseEntity<?>getallusers();
	}

