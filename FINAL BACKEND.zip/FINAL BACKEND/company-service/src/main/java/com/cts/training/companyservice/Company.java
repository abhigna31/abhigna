package com.cts.training.companyservice;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
@Entity
@Table(name = "company")
@XmlRootElement(name="com")

public class Company  implements Serializable {
	

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue
	private int id;
	private String sector;
	private String name;
	private String ceo;
	private String bod;
	private long turnover;
	private String CompanyCode;
	
	public Company() {}
	
	
	public Company(int id, String sector, String name, String ceo, String bod, long turnover, String companyCode) {
		super();
		this.id = id;
		this.sector = sector;
		this.name = name;
		this.ceo = ceo;
		this.bod = bod;
		this.turnover = turnover;
		this.CompanyCode = companyCode;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSector() {
		return sector;
	}
	public void setSector(String sector) {
		this.sector = sector;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCeo() {
		return ceo;
	}
	public void setCeo(String ceo) {
		this.ceo = ceo;
	}
	public String getBod() {
		return bod;
	}
	public void setBod(String bod) {
		this.bod = bod;
	}
	public long getTurnover() {
		return turnover;
	}
	public void setTurnover(long turnover) {
		this.turnover = turnover;
	}
	public String getCompanyCode() {
		return CompanyCode;
	}
	public void setCompanyCode(String companyCode) {
		this.CompanyCode = companyCode;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
	
	